#include "HackEnrollment.h"
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

int cloneAndLower(const char* sourceFile, const char* destFile) {
    FILE *src_fp, *dest_fp;
    char c;
    
    // Open source file for reading
    src_fp = fopen(sourceFile, "r");
    if (src_fp == NULL) {
        printf("Error opening source file: %s\n", sourceFile);
        return 1;
    }
    
    // Open destination file for writing
    dest_fp = fopen(destFile, "w");
    if (dest_fp == NULL) {
        printf("Error opening destination file: %s\n", destFile);
        fclose(src_fp);
        return 1;
    }
    
    // Copy contents of source file to destination file, converting uppercase to lowercase
    while ((c = fgetc(src_fp)) != EOF) {
        fputc(tolower(c), dest_fp);
    }
    
    // Close files
    fclose(src_fp);
    fclose(dest_fp);
    
    return 0;
}

int main(int argc, char *argv[]) {
    int argCount = 0;
    FILE* students;
    
    if (argc != 6 && argc != 7){
        printf("incorrect arguments\n");
        printf("correct format: ./HackEnrollment <flags> <students> <courses> <hackers> <queues> <target>\n");
        return 1;
    }

    argCount = 1;
    if(argc == 7){ // flag 'i'
        char *flag = argv[argCount++];
        if (strcmp(flag, "-i") != 0){
            printf("incorrect flag for ignoring letter case\n");
            printf("correct flag: -i\n");
            return 2;
        }
        cloneAndLower(argv[argCount++], "studentsClone.txt");
        students = fopen("studentsClone.txt", "r");
    }
    else{
        students = fopen(argv[argCount++],"r");
    }

    FILE* courses = fopen(argv[argCount++] ,"r");
    FILE* hackers = fopen(argv[argCount++] ,"r");
    FILE* queues = fopen(argv[argCount++], "r");
    FILE* target = fopen(argv[argCount++], "w");

    if (!students || !courses || !hackers || !queues || !target){
        printf("couldn't open files\n");
        return 3;
    }

    EnrollmentSystem sys = createEnrollment(students, courses, hackers);
    if (sys == NULL) return 4;

    sys = readEnrollment(sys, queues);
    if (sys == NULL) return 5;

    if (hackEnrollment(sys, target) != HACKENROLLMENT_SUCCESS){
        printf("hackEnrollment ERROR\n");
    }

    destroyEnrollment(sys);
    fclose(students);
    fclose(courses);
    fclose(hackers);
    fclose(queues);
    fclose(target);
  

	return 0;
}